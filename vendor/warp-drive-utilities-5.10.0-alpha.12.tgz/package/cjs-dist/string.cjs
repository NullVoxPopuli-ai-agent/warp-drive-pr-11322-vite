Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
//#region ../../node_modules/.pnpm/@warp-d_5e1563e0e582c8365bb74466d3761d6d/node_modules/@warp-drive/core/dist/utils/string.js
const DEFAULT_MAX_CACHE_SIZE = 1e4;
/**
* An LRUCache implementation with upsert semantics.
*
* This implementation is *not* generic, but focuses on
* performance tuning for the string transformation cases
* where the key maps to the value very simply.
*
* It takes a work function that should generate a new value
* for a given key when called. It will be called when the key
* is not found in the cache.
*
* It keeps track of the number of hits, misses, and ejections
* in DEBUG envs, which is useful for tuning the cache size.
*
* This is an internal utility class for use by this module
* and by `@warp-drive/utilities/string`. It is not intended
* for use outside of these modules at this time.
*
* @private
*/
var LRUCache = class {
	constructor(doWork, size) {
		this.size = size || DEFAULT_MAX_CACHE_SIZE;
		this.state = /* @__PURE__ */ new Map();
		this.doWork = doWork;
	}
	get(key) {
		const value = this.state.get(key);
		if (value) {
			this.state.delete(key);
			this.state.set(key, value);
			return value;
		}
		const newValue = this.doWork(key);
		this.set(key, newValue);
		return newValue;
	}
	set(key, value) {
		if (this.state.size === this.size) for (const [k] of this.state) {
			this.state.delete(k);
			break;
		}
		this.state.set(key, value);
	}
	clear() {
		this.state.clear();
	}
};
const STRING_DASHERIZE_REGEXP = /[ _]/g;
const STRING_DECAMELIZE_REGEXP = /([a-z\d])([A-Z])/g;
/**
* The {@link LRUCache} backing {@link dasherize}, keyed by the original
* (un-dasherized) string.
*
* @private
*/
const STRING_DASHERIZE_CACHE = new LRUCache((key) => key.replace(STRING_DECAMELIZE_REGEXP, "$1_$2").toLowerCase().replace(STRING_DASHERIZE_REGEXP, "-"));
/**
* This is an internal utility function that converts a string
* to a dasherized format. Library consumers should use the
* re-exported version from `@warp-drive/utilities/string` instead.
*
* This version is only in this location to support a deprecated
* behavior in the core package and will be removed in a future.
*
* @private
*/
function dasherize$1(str) {
	return STRING_DASHERIZE_CACHE.get(str);
}

//#endregion
//#region src/-private/string/inflections.ts
const defaultRules = {
	plurals: [
		[/$/, "s"],
		[/s$/i, "s"],
		[/^(ax|test)is$/i, "$1es"],
		[/(octop|vir)us$/i, "$1i"],
		[/(octop|vir)i$/i, "$1i"],
		[/(alias|status|bonus)$/i, "$1es"],
		[/(tu|bu)s$/i, "$1ses"],
		[/(buffal|tomat)o$/i, "$1oes"],
		[/([ti])um$/i, "$1a"],
		[/([ti])a$/i, "$1a"],
		[/sis$/i, "ses"],
		[/(?:([^f])fe|([lr])f)$/i, "$1$2ves"],
		[/(hive)$/i, "$1s"],
		[/([^aeiouy]|qu)y$/i, "$1ies"],
		[/(x|ch|ss|sh)$/i, "$1es"],
		[/(matr|vert|ind)(?:ix|ex)$/i, "$1ices"],
		[/^(m|l)ouse$/i, "$1ice"],
		[/^(m|l)ice$/i, "$1ice"],
		[/^(ox)$/i, "$1en"],
		[/^(oxen)$/i, "$1"],
		[/(quiz)$/i, "$1zes"]
	],
	singular: [
		[/s$/i, ""],
		[/(ss)$/i, "$1"],
		[/(n)ews$/i, "$1ews"],
		[/([ti])a$/i, "$1um"],
		[/((a)naly|(b)a|(d)iagno|(p)arenthe|(p)rogno|(s)ynop|(t)he)(sis|ses)$/i, "$1sis"],
		[/(^analy)(sis|ses)$/i, "$1sis"],
		[/([^f])ves$/i, "$1fe"],
		[/(hive)s$/i, "$1"],
		[/(tive)s$/i, "$1"],
		[/([lr])ves$/i, "$1f"],
		[/([^aeiouy]|qu)ies$/i, "$1y"],
		[/(s)eries$/i, "$1eries"],
		[/(m)ovies$/i, "$1ovie"],
		[/(x|ch|ss|sh)es$/i, "$1"],
		[/^(m|l)ice$/i, "$1ouse"],
		[/(tus|bus)(es)?$/i, "$1"],
		[/(o)es$/i, "$1"],
		[/(shoe)s$/i, "$1"],
		[/(cris|test)(is|es)$/i, "$1is"],
		[/^(a)x[ie]s$/i, "$1xis"],
		[/(octop|vir)(us|i)$/i, "$1us"],
		[/(alias|status|bonus)(es)?$/i, "$1"],
		[/^(ox)en/i, "$1"],
		[/(vert|ind)ices$/i, "$1ex"],
		[/(matr)ices$/i, "$1ix"],
		[/(quiz)zes$/i, "$1"],
		[/(database)s$/i, "$1"]
	],
	irregularPairs: [
		["person", "people"],
		["man", "men"],
		["child", "children"],
		["sex", "sexes"],
		["move", "moves"],
		["cow", "kine"],
		["zombie", "zombies"]
	],
	uncountable: [
		"equipment",
		"information",
		"rice",
		"money",
		"species",
		"series",
		"fish",
		"sheep",
		"jeans",
		"police"
	]
};

//#endregion
//#region src/-private/string/transform.ts
const STRING_CAMELIZE_REGEXP_1 = /(\-|\_|\.|\s)+(.)?/g;
const STRING_CAMELIZE_REGEXP_2 = /(^|\/)([A-Z])/g;
const CAMELIZE_CACHE = new LRUCache((key) => key.replace(STRING_CAMELIZE_REGEXP_1, (_match, _separator, chr) => chr ? chr.toUpperCase() : "").replace(STRING_CAMELIZE_REGEXP_2, (match) => match.toLowerCase()));
const STRING_UNDERSCORE_REGEXP_1 = /([a-z\d])([A-Z]+)/g;
const STRING_UNDERSCORE_REGEXP_2 = /\-|\s+/g;
const UNDERSCORE_CACHE = new LRUCache((str) => str.replace(STRING_UNDERSCORE_REGEXP_1, "$1_$2").replace(STRING_UNDERSCORE_REGEXP_2, "_").toLowerCase());
const STRING_CAPITALIZE_REGEXP = /(^|\/)([a-z\u00C0-\u024F])/g;
const CAPITALIZE_CACHE = new LRUCache((str) => str.replace(STRING_CAPITALIZE_REGEXP, (match) => match.toUpperCase()));
/**
* Replaces underscores, spaces, or camelCase with dashes.
*
* ```js
* import { dasherize } from '@warp-drive/utilities/string';
*
* dasherize('innerHTML');                // 'inner-html'
* dasherize('action_name');              // 'action-name'
* dasherize('css-class-name');           // 'css-class-name'
* dasherize('my favorite items');        // 'my-favorite-items'
* dasherize('privateDocs/ownerInvoice';  // 'private-docs/owner-invoice'
* ```
*
* @summary Converts camelCase, underscored, or spaced strings to dasherized form, such as `innerHTML` to `inner-html`.
* @public
* @since 4.13.0
*/
const dasherize = dasherize$1;
/**
* Returns the lowerCamelCase form of a string.
*
* ```js
* import { camelize } from '@warp-drive/utilities/string';
*
* camelize('innerHTML');                   // 'innerHTML'
* camelize('action_name');                 // 'actionName'
* camelize('css-class-name');              // 'cssClassName'
* camelize('my favorite items');           // 'myFavoriteItems'
* camelize('My Favorite Items');           // 'myFavoriteItems'
* camelize('private-docs/owner-invoice');  // 'privateDocs/ownerInvoice'
* ```
*
* @summary Converts dashed, underscored, dotted, or spaced strings to lowerCamelCase, such as `action_name` to
* `actionName`.
* @public
* @since 4.13.0
*/
function camelize(str) {
	return CAMELIZE_CACHE.get(str);
}
/**
* Returns the lower\_case\_and\_underscored form of a string.
*
* ```js
* import { underscore } from '@warp-drive/utilities/string';
*
* underscore('innerHTML');                 // 'inner_html'
* underscore('action_name');               // 'action_name'
* underscore('css-class-name');            // 'css_class_name'
* underscore('my favorite items');         // 'my_favorite_items'
* underscore('privateDocs/ownerInvoice');  // 'private_docs/owner_invoice'
* ```
*
* @summary Converts camelCase, dashed, or spaced strings to lowercase snake_case, such as `innerHTML` to `inner_html`.
* @public
* @since 4.13.0
*/
function underscore(str) {
	return UNDERSCORE_CACHE.get(str);
}
/**
* Returns the Capitalized form of a string
*
* ```js
* import { capitalize } from '@warp-drive/utilities/string';
*
* capitalize('innerHTML')                 // 'InnerHTML'
* capitalize('action_name')               // 'Action_name'
* capitalize('css-class-name')            // 'Css-class-name'
* capitalize('my favorite items')         // 'My favorite items'
* capitalize('privateDocs/ownerInvoice'); // 'PrivateDocs/ownerInvoice'
* ```
*
* @summary Uppercases the first letter of a string, and of each `/`-separated path segment, leaving the rest unchanged.
* @public
* @since 4.13.0
*/
function capitalize(str) {
	return CAPITALIZE_CACHE.get(str);
}
/**
* Sets the maximum size of the LRUCache for all string transformation functions.
* The default size is 10,000.
*
* @summary Sets how many results the `camelize`, `underscore`, `capitalize`, and `dasherize` caches each keep (default
* 10,000).
* @public
* @since 4.13.0
*/
function setMaxLRUCacheSize(size) {
	CAMELIZE_CACHE.size = size;
	UNDERSCORE_CACHE.size = size;
	CAPITALIZE_CACHE.size = size;
	STRING_DASHERIZE_CACHE.size = size;
}

//#endregion
//#region src/-private/string/inflect.ts
const BLANK_REGEX = /^\s*$/;
const LAST_WORD_DASHED_REGEX = /([\w/-]+[_/\s-])([a-z\d]+$)/;
const LAST_WORD_CAMELIZED_REGEX = /([\w/\s-]+)([A-Z][a-z\d]*$)/;
const CAMELIZED_REGEX = /[A-Z][a-z\d]*$/;
const SINGULARS = new LRUCache((word) => {
	return _singularize(word);
});
const PLURALS = new LRUCache((word) => {
	return _pluralize(word);
});
const UNCOUNTABLE = new Set(defaultRules.uncountable);
const IRREGULAR = /* @__PURE__ */ new Map();
const INVERSE_IRREGULAR = /* @__PURE__ */ new Map();
const SINGULAR_RULES = new Map(defaultRules.singular.reverse());
const PLURAL_RULES = new Map(defaultRules.plurals.reverse());
/**
* Marks a word as uncountable. Uncountable words are not pluralized
* or singularized.
*
* @summary Registers a word that `pluralize` and `singularize` should always return unchanged.
* @public
* @since 4.13.0
*/
function uncountable(word) {
	UNCOUNTABLE.add(word.toLowerCase());
}
/**
* Marks a list of words as uncountable. Uncountable words are not pluralized
* or singularized.
*
* @summary Registers a list of words that `pluralize` and `singularize` should always return unchanged.
* @public
* @since 4.13.0
*/
function loadUncountable(uncountables) {
	uncountables.forEach((word) => {
		uncountable(word);
	});
}
/**
* Marks a word as irregular. Irregular words have unique
* pluralization and singularization rules.
*
* @summary Registers a singular and plural word pair that `pluralize` and `singularize` map directly instead of
* applying rules.
* @public
* @since 4.13.0
*/
function irregular(single, plur) {
	IRREGULAR.set(single.toLowerCase(), plur);
	IRREGULAR.set(plur.toLowerCase(), plur);
	INVERSE_IRREGULAR.set(plur.toLowerCase(), single);
	INVERSE_IRREGULAR.set(single.toLowerCase(), single);
}
/**
* Marks a list of word pairs as irregular. Irregular words have unique
* pluralization and singularization rules.
*
* @summary Registers a list of singular and plural word pairs that `pluralize` and `singularize` map directly.
* @public
* @since 4.13.0
*/
function loadIrregular(irregularPairs) {
	irregularPairs.forEach((pair) => {
		IRREGULAR.set(pair[0].toLowerCase(), pair[1]);
		IRREGULAR.set(pair[1].toLowerCase(), pair[1]);
		INVERSE_IRREGULAR.set(pair[1].toLowerCase(), pair[0]);
		INVERSE_IRREGULAR.set(pair[0].toLowerCase(), pair[0]);
	});
}
loadIrregular(defaultRules.irregularPairs);
/**
* Clears the caches for singularize and pluralize.
*
* @summary Empties the cached results of `singularize` and `pluralize` while keeping all inflection rules.
* @public
* @since 4.13.0
*/
function clear() {
	SINGULARS.clear();
	PLURALS.clear();
}
/**
* Resets the inflection rules to the defaults.
*
* @summary Discards all custom inflection rules and caches, then restores the built-in default rules.
* @public
* @since 4.13.0
*/
function resetToDefaults() {
	clearRules();
	defaultRules.uncountable.forEach((v) => UNCOUNTABLE.add(v));
	defaultRules.singular.forEach((v) => SINGULAR_RULES.set(v[0], v[1]));
	defaultRules.plurals.forEach((v) => PLURAL_RULES.set(v[0], v[1]));
	loadIrregular(defaultRules.irregularPairs);
}
/**
* Clears all inflection rules
* and resets the caches for singularize and pluralize.
*
* @summary Removes every inflection rule, including the defaults, and empties the `singularize` and `pluralize` caches.
* @public
* @since 4.13.0
*/
function clearRules() {
	SINGULARS.clear();
	PLURALS.clear();
	UNCOUNTABLE.clear();
	IRREGULAR.clear();
	INVERSE_IRREGULAR.clear();
	SINGULAR_RULES.clear();
	PLURAL_RULES.clear();
}
/**
* Singularizes a word.
*
* @summary Returns the singular form of an English word using the registered inflection rules, with cached results.
* @public
* @since 4.13.0
*/
function singularize(word) {
	if (!word) return "";
	return SINGULARS.get(word);
}
/**
* Pluralizes a word.
*
* @summary Returns the plural form of an English word using the registered inflection rules, with cached results.
* @public
* @since 4.13.0
*/
function pluralize(word) {
	if (!word) return "";
	return PLURALS.get(word);
}
function unshiftMap(v, map) {
	const rules = [v, ...map.entries()];
	map.clear();
	rules.forEach((rule) => {
		map.set(rule[0], rule[1]);
	});
}
/**
* Adds a pluralization rule.
*
* @summary Adds a regex and replacement rule that `pluralize` checks before all existing plural rules.
* @public
* @since 4.13.0
*/
function plural(regex, string) {
	if (PLURAL_RULES.has(regex)) PLURAL_RULES.delete(regex);
	unshiftMap([regex, string], PLURAL_RULES);
}
/**
* Adds a singularization rule.
*
* @summary Adds a regex and replacement rule that `singularize` checks before all existing singular rules.
* @public
* @since 4.13.0
*/
function singular(regex, string) {
	if (SINGULAR_RULES.has(regex)) SINGULAR_RULES.delete(regex);
	unshiftMap([regex, string], SINGULAR_RULES);
}
function _pluralize(word) {
	return inflect(word, PLURAL_RULES, IRREGULAR);
}
function _singularize(word) {
	return inflect(word, SINGULAR_RULES, INVERSE_IRREGULAR);
}
function inflect(word, typeRules, irregulars) {
	if (!word || BLANK_REGEX.test(word)) return word;
	const lowercase = word.toLowerCase();
	if (UNCOUNTABLE.has(lowercase)) return word;
	const wordSplit = LAST_WORD_DASHED_REGEX.exec(word) || LAST_WORD_CAMELIZED_REGEX.exec(word);
	const lastWord = wordSplit ? wordSplit[2].toLowerCase() : null;
	if (lastWord && UNCOUNTABLE.has(lastWord)) return word;
	const isCamelized = CAMELIZED_REGEX.test(word);
	for (let [rule, substitution] of irregulars) if (lowercase.match(rule + "$")) {
		if (isCamelized && lastWord && irregulars.has(lastWord)) {
			substitution = capitalize(substitution);
			rule = capitalize(rule);
		}
		return word.replace(new RegExp(rule, "i"), substitution);
	}
	for (const [rule, substitution] of typeRules) if (rule.test(word)) return word.replace(rule, substitution);
	return word;
}

//#endregion
exports.camelize = camelize;
exports.capitalize = capitalize;
exports.clear = clear;
exports.clearRules = clearRules;
exports.dasherize = dasherize;
exports.irregular = irregular;
exports.loadIrregular = loadIrregular;
exports.loadUncountable = loadUncountable;
exports.plural = plural;
exports.pluralize = pluralize;
exports.resetToDefaults = resetToDefaults;
exports.setMaxLRUCacheSize = setMaxLRUCacheSize;
exports.singular = singular;
exports.singularize = singularize;
exports.uncountable = uncountable;
exports.underscore = underscore;
//# sourceMappingURL=string.cjs.map